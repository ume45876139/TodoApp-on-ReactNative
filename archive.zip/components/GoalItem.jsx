import React from 'react';
import {View, Text, Switch } from 'react-native';
import styles from '../styles';

class GoalItem extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <View style={styles.itemWrapper}>
        <Text style={styles.eachItem}>{this.props.item.id}.{this.props.item.content}</Text>
        <Switch style={styles.switchPosition}/>
      </View>
    );
  }
}

export default GoalItem;